#!/bin/bash

echo "Dummy task is executing: $(date)" | cat >> trash/30.txt