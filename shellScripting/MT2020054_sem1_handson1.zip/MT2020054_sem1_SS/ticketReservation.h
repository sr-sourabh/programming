struct ticketReservation{
    int number;
};