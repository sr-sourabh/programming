The project aims to develop a banking system that is user-friendly and multi-
functional. 

It is scalable and implements features such as real time locking, concurrent clients support.

First step is to run adminCredentialSetup.c file which makes an admin user with userId and password as admin.

Then run server.

Lastly run client.