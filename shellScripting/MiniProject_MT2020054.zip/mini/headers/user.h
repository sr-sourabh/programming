struct user{
    char userId[20];
    char userName[20];
    int balance;
    char password[20];
    int type; //1 for normal user, 2 for joint user
};