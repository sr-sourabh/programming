char invalidCredentials[] = "INVALID_CREDENTIALS";
char usernameNotUnique[] = "USERNAME_NOT_UNIQUE";
char success[] = "SUCCESS";
char notFound[] = "USERID_NOT_FOUND";