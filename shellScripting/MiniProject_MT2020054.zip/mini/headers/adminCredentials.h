const char *adminCredFile = "db/adminCredentials.dat";
char adminUserId[] = "admin";
char adminPassword[] = "admin";

struct AdminCredentials{
        char userId[20];
        char password[20];
};

