#! /bin/bash

if [ $# -eq 3 ]
then
  echo "$@"
else
  echo wrong
fi