How to run?
    
    $bash 1.sh
    $bash 2.sh one two three
    $bash 3_new_files.sh myfile1 myfile2
    $bash 4_myrm.sh
    $bash 5.sh
    $bash 6.sh
    $bash 7.sh
    $bash 8.sh loginName
    $bash 9.sh 7.sh 2 6
    $bash 10.sh 10 myfile
    $bash 11.sh tmpfs
    $bash 12.sh
    $bash 13.sh
    $bash 14.sh
    $bash 15.sh example
    $bash 16.sh employee.txt
