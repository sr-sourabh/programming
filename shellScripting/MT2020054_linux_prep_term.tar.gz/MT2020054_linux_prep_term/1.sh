#! /bin/bash
ls -lh /dev | grep '^[b]' | wc -l
